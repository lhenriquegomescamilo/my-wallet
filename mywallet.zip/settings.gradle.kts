rootProject.name = "com.mywallet"
