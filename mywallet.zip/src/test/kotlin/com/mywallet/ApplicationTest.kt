package com.mywallet

class ApplicationTest {
}
